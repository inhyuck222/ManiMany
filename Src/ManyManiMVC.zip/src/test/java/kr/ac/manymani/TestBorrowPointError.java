package kr.ac.manymani;

import java.util.regex.Pattern;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

import junit.framework.Assert;

public class TestBorrowPointError {
  private WebDriver driver;
  private String baseUrl;
  private boolean acceptNextAlert = true;
  private StringBuffer verificationErrors = new StringBuffer();
  
  @Before
  public void setUp() throws Exception {
    driver = new FirefoxDriver();
    baseUrl = "http://113.198.84.85:8080/";
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
  }

  @Test
  public void testBorrowPointError() throws Exception {
	  driver.get(baseUrl + "/ManyManiMVC/");
	    driver.findElement(By.linkText("Login")).click();
	    driver.findElement(By.name("id")).click();
	    driver.findElement(By.name("id")).clear();
	    driver.findElement(By.name("id")).sendKeys("1191078");
	   	
	    driver.findElement(By.name("password")).click();
	    driver.findElement(By.name("password")).clear();
	    driver.findElement(By.name("password")).sendKeys("8118");
	    
	    driver.findElement(By.cssSelector("input[type=\"submit\"]")).click();
	    	        
	    driver.findElement(By.linkText("�뿩�ϱ�")).click();
	    driver.findElement(By.name("bookNumber")).click();
	    driver.findElement(By.name("bookNumber")).clear();
	    driver.findElement(By.name("bookNumber")).sendKeys("112211");
	    
	    WebElement element =  driver.findElement(By.name("bookNumber"));
	    String bookNumber = element.getAttribute("value");
	    Assert.assertEquals("112211", bookNumber);
	    
	    WebElement submit = driver.findElement(By.name("bookNumber"));
	    submit.sendKeys(Keys.ENTER);
	    
	    String test_url = driver.getCurrentUrl();
	    Assert.assertEquals("http://113.198.84.85:8080/ManyManiMVC/DoBorrowBook", test_url);
	    
	    driver.findElement(By.name("point")).click();
	    driver.findElement(By.name("point")).clear();
	    driver.findElement(By.name("point")).sendKeys("300");
	    
	    element =  driver.findElement(By.name("point"));
	    String point= element.getAttribute("value");
	    Assert.assertEquals("300", point);
	    
	    submit = driver.findElement(By.name("point"));
	    submit.sendKeys(Keys.ENTER);
	    
	    try { 
	        Alert alert = driver.switchTo().alert();
	        alert.accept();
	    }
	    catch (NoAlertPresentException e) {
	    	e.printStackTrace();
	    }
	    test_url = driver.getCurrentUrl();
	    Assert.assertEquals("http://113.198.84.85:8080/ManyManiMVC/borrowBook", test_url);
  }

  @After
  public void tearDown() throws Exception {
    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

  private boolean isElementPresent(By by) {
    try {
      driver.findElement(by);
      return true;
    } catch (NoSuchElementException e) {
      return false;
    }
  }

  private boolean isAlertPresent() {
    try {
      driver.switchTo().alert();
      return true;
    } catch (NoAlertPresentException e) {
      return false;
    }
  }

  private String closeAlertAndGetItsText() {
    try {
      Alert alert = driver.switchTo().alert();
      String alertText = alert.getText();
      if (acceptNextAlert) {
        alert.accept();
      } else {
        alert.dismiss();
      }
      return alertText;
    } finally {
      acceptNextAlert = true;
    }
  }
}
